package com.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.Collection;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.servlet.http.HttpSession;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.model.orders;
import com.model.photo;
import com.model.user;
import com.service.orderservice;
import com.service.photoservice;
import com.service.userservice;


@RestController

public class usercontroller {
	
	String username;
	String useremail;
	String transaction;
	int size;
	int total;
	boolean sign;
	boolean placesign;
	String add;
	
	 Collection<photo> c;
	
	
	 @Autowired
	  userservice serv;
	 
	 
	 @Autowired
	  orderservice orderserv;
	 
	 
	 
	
	 @Autowired
	 photoservice pser;
	 
	 private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	 HttpSession httpS;
	 Session s;
	 
	 private static final String ALPHA_NUMERIC_STRING_BEG = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		private static final String ALPHA_NUMERIC_STRING_END = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		private static final String ALPHA_NUMERIC_STRING_NUM = "9876543210";
	 
	 /*  MAIN PAGE WHEN SITE IS LOADED*/
	 
	@RequestMapping("/")
	   
	
	 
	 
	/*MAIN PAGE OB LOADING*/
	 
	
	 
	 
	public ModelAndView mainpageonlaoding(Model model1,Model model2,Model model3,
	Model model4,Model model5,Model model6,Model model7,Model model8 ) {
   
  


 
   ModelAndView ob= new ModelAndView("home");
   
photo p1=pser.getphoto("HomePage1");
     model1.addAttribute("image1", 
     Base64.getEncoder().encodeToString(p1.getImage().getData()));
  
	 
      ob.addObject("model1", model1);
     
      
      
      
      
      
      photo p2=pser.getphoto("HomePage2");
	     model2.addAttribute("image2", 
	     Base64.getEncoder().encodeToString(p2.getImage().getData()));
	     model2.addAttribute("dis2", p2.getDescription());
	   ob.addObject("model2", model2);
	     
      
	   photo p3=pser.getphoto("GalleryImage1");
	     model3.addAttribute("image3", 
	     Base64.getEncoder().encodeToString(p3.getImage().getData()));
	    
	   ob.addObject("model3", model3);
	  
      
	   
	   photo p4=pser.getphoto("GalleryImage2");
	     model4.addAttribute("image4", 
	     Base64.getEncoder().encodeToString(p4.getImage().getData()));
	    
	   ob.addObject("model4", model4);
	   
	   
	   photo p5=pser.getphoto("GalleryImage3");
	     model5.addAttribute("image5", 
	     Base64.getEncoder().encodeToString(p5.getImage().getData()));
	    
	   ob.addObject("model5", model5);
	   
	   
	   photo p6=pser.getphoto("GalleryImage4");
	     model6.addAttribute("image6", 
	     Base64.getEncoder().encodeToString(p6.getImage().getData()));
	    
	   ob.addObject("model6", model6);
	   
	   
	   photo p7=pser.getphoto("GalleryImage5");
	     model7.addAttribute("image7", 
	     Base64.getEncoder().encodeToString(p7.getImage().getData()));
	    
	   ob.addObject("model7", model7);
	   
	   
	   photo p8=pser.getphoto("GalleryImage6");
	     model8.addAttribute("image8", 
	     Base64.getEncoder().encodeToString(p8.getImage().getData()));
	    
	   ob.addObject("model8", model8);
      
      
     
     
      return ob;
   }

	 @RequestMapping( value= "/pay" )

	 public ModelAndView pay(Model model1,@RequestParam("deliveryaddress")String address) {
		 ModelAndView ob= new ModelAndView("paytmpay");
		 
		 
		 String transactionid=getTransactionID();
		 
		 transaction=transactionid;
		 add=address;
		 
		 model1.addAttribute("transactionid",transactionid);
		 
		 model1.addAttribute("name",username);
			ob.addObject("model1", model1);
		 return ob;
		 
	 }
	 
	 
	 
	 
	 
	 @RequestMapping( value= "/paypaytm" )

	 public ModelAndView paypaytm(Model model1) {
		 ModelAndView ob= new ModelAndView("recipt");
	 
		   
		    orders obj= new orders();
		    
		    obj.setEmail(useremail);
		    obj.setName(username);
		    obj.setTotalamount(total);
		    obj.setNoofitems(size);
		    obj.setTransac(transaction);
		    obj.setAddress(add);
		   
		    
		    
		    sendmail();
		    orderserv.createorder(obj);
		 
   model1.addAttribute("transactionid",transaction);
		 model1.addAttribute("total",total);
		 model1.addAttribute("size",size);
		 model1.addAttribute("name",username);
			ob.addObject("model1", model1);
		 
		 
		 return ob;
	 }
	
	/*ADD TO CART*/
	
	 
	 @RequestMapping( value= "/addtocart" )
		 
	 public ModelAndView addtocart1(@RequestParam("cart")String id,Model model1,Model model2,Model model3,Model model4,Model model5,Model model6,
			 Model model7, Model model8,Model model9){
		 
		 ModelAndView ob= new ModelAndView("foodmenu");
		 photo p1=pser.getphoto("Drink1");
			
		 
		     model1.addAttribute("title", p1.getTitle());
		     model1.addAttribute("image1", 
		     Base64.getEncoder().encodeToString(p1.getImage().getData()));
		     model1.addAttribute("id", p1.getId());
		     model1.addAttribute("title1", p1.getTitle());
		     model1.addAttribute("price1", p1.getPrice());
		     model1.addAttribute("dis1",p1.getDescription());
		
		     ob.addObject("model1", model1);
		     
		     
		     photo p2=pser.getphoto("Drink2");
				
			     model2.addAttribute("title", p2.getTitle());
			     model2.addAttribute("image2", 
			     Base64.getEncoder().encodeToString(p2.getImage().getData()));
			     model2.addAttribute("id", p2.getId());
			     model2.addAttribute("title2", p2.getTitle());
			     model2.addAttribute("price2", p2.getPrice());
			     model2.addAttribute("dis2",p2.getDescription());
				 
			     ob.addObject("model2", model2);
			    
			     
			     
			     
			     
			     
			    photo p3=pser.getphoto("Drink3");
					
			     model3.addAttribute("title", p3.getTitle());
			     model3.addAttribute("image3", 
			     Base64.getEncoder().encodeToString(p3.getImage().getData()));
			     model3.addAttribute("id", p3.getId());
			     model3.addAttribute("title3", p3.getTitle());
			     model3.addAttribute("price3", p3.getPrice());
			     model3.addAttribute("dis3",p3.getDescription());
				 
			     ob.addObject("model3", model3);
			    
				    photo p4=pser.getphoto("Snack1");
						
				     model4.addAttribute("title", p4.getTitle());
				     model4.addAttribute("image4", 
				     Base64.getEncoder().encodeToString(p4.getImage().getData()));
				     model4.addAttribute("id", p4.getId());
				     model4.addAttribute("title4", p4.getTitle());
				     model4.addAttribute("price4", p4.getPrice());
				     model4.addAttribute("dis4",p4.getDescription());
					 
				     ob.addObject("model4", model4);
			     
				     photo p5=pser.getphoto("Snack2");
						
				     model5.addAttribute("title", p5.getTitle());
				     model5.addAttribute("image5", 
				     Base64.getEncoder().encodeToString(p5.getImage().getData()));
				     model5.addAttribute("id", p5.getId());
				     model5.addAttribute("title5", p5.getTitle());
				     model5.addAttribute("price5", p5.getPrice());
				     model5.addAttribute("dis5",p5.getDescription());
					 
				     ob.addObject("model5", model5);
				     
				     photo p6=pser.getphoto("Snack3");
						
				     model6.addAttribute("title", p6.getTitle());
				     model6.addAttribute("image6", 
				     Base64.getEncoder().encodeToString(p6.getImage().getData()));
				     model6.addAttribute("id", p6.getId());
				     model6.addAttribute("title6", p6.getTitle());
				     model6.addAttribute("price6", p6.getPrice());
				     model6.addAttribute("dis6",p6.getDescription());
					 
				     ob.addObject("model6", model6);
		     
		 
		     
				     photo p7=pser.getphoto("Desert1");
						
				     model7.addAttribute("title", p7.getTitle());
				     model7.addAttribute("image7", 
				     Base64.getEncoder().encodeToString(p7.getImage().getData()));
				     model7.addAttribute("id", p7.getId());
				     model7.addAttribute("title7", p7.getTitle());
				     model7.addAttribute("price7", p7.getPrice());
				     model7.addAttribute("dis7",p7.getDescription());
					 
				     ob.addObject("model7", model7);
		     
				     
				     photo p8=pser.getphoto("Desert2");
						
				     model8.addAttribute("title", p8.getTitle());
				     model8.addAttribute("image8", 
				     Base64.getEncoder().encodeToString(p8.getImage().getData()));
				     model8.addAttribute("id", p8.getId());
				     model8.addAttribute("title8", p8.getTitle());
				     model8.addAttribute("price8", p8.getPrice());
				     model8.addAttribute("dis8",p8.getDescription());
					 
				     ob.addObject("model8", model8);
		     
				     
				     photo p9=pser.getphoto("Desert3");
						
				     model9.addAttribute("title", p9.getTitle());
				     model9.addAttribute("image9", 
				     Base64.getEncoder().encodeToString(p9.getImage().getData()));
				     model9.addAttribute("id9", p9.getId());
				     model9.addAttribute("title9", p9.getTitle());
				     model9.addAttribute("price9", p9.getPrice());
				     model9.addAttribute("dis9",p9.getDescription());
					 
				     ob.addObject("model9", model9);
		     
				     
				     
				     
				     
				     
				     
				     
				     
				     
	
		 System.out.print(id);
		 
		 
		 photo photo=pser.getphoto(id);
		 
			
			
			
			photo p= new photo();
			p.setPrice(photo.getPrice());
            p.setTitle(photo.getTitle());
            p.setId(photo.getId());
		
			
            total=total+photo.getPrice();
            
            pser.addproduct(p);
            
		
			
			
			return ob;
			
	 }
	
	 /*PLACE ORDER CLICKED*/
	 
	 @RequestMapping( value= "/placeorder" )
	 
	 
	 public ModelAndView placeorder(Model model1){
		 
		 
		 
		 
		 
		 if(sign==true) {
			 
			 
			 
			 
			 
			 
			 c=pser.getAllproduct();
			    
			int    size1=c.size();
			   
			    
			    if(c.size()>0) {
			   
			    

			    ModelAndView ob1= new ModelAndView("userdashboard");
			    model1.addAttribute("total",total);
			    model1.addAttribute("totalitems",size1);
			
			   
			    
			    
			    
			 
			    
			    model1.addAttribute("name",username);
				ob1.addObject("model1", model1);
				
					
					ob1.addObject("c", c);
				
				
			 
					 return ob1;
			 
			    }else {
			    	ModelAndView ob1= new ModelAndView("userorders"); 	
			    	
			    	  model1.addAttribute("name", username);
						ob1.addObject("model1", model1);
			    	
			    
			    	
			    	
			    	 return ob1;
			    	
			    	
			    }
			
			 
			 
			 
		 }else {
		 
		 
			 placesign=true;
			 
		 ModelAndView ob= new ModelAndView("login");
			
	
		
           
		
			
			
			return ob;
			
		 }
		 
		 
		 
			
	 }
	 
	 
	 
	 
	 
	 
	 
/*WHEN HOME NAV LINK IS CLICKED*/
	 
	 @RequestMapping("/home")
	   
	   public ModelAndView homepage(Model model1,Model model2,Model model3,
				Model model4,Model model5,Model model6,Model model7,Model model8) {
		   
		   
		   ModelAndView ob= new ModelAndView("home");
			photo p1=pser.getphoto("HomePage1");
		     model1.addAttribute("image1", 
		     Base64.getEncoder().encodeToString(p1.getImage().getData()));
		  
			 
		      ob.addObject("model1", model1);
		     
		      
		      
		      
		      
		      
		      photo p2=pser.getphoto("HomePage2");
			     model2.addAttribute("image2", 
			     Base64.getEncoder().encodeToString(p2.getImage().getData()));
			     model2.addAttribute("dis2", p2.getDescription());
			   ob.addObject("model2", model2);
			     
		      
			   photo p3=pser.getphoto("GalleryImage1");
			     model3.addAttribute("image3", 
			     Base64.getEncoder().encodeToString(p3.getImage().getData()));
			    
			   ob.addObject("model3", model3);
			  
		      
			   
			   photo p4=pser.getphoto("GalleryImage2");
			     model4.addAttribute("image4", 
			     Base64.getEncoder().encodeToString(p4.getImage().getData()));
			    
			   ob.addObject("model4", model4);
			   
			   
			   photo p5=pser.getphoto("GalleryImage3");
			     model5.addAttribute("image5", 
			     Base64.getEncoder().encodeToString(p5.getImage().getData()));
			    
			   ob.addObject("model5", model5);
			   
			   
			   photo p6=pser.getphoto("GalleryImage4");
			     model6.addAttribute("image6", 
			     Base64.getEncoder().encodeToString(p6.getImage().getData()));
			    
			   ob.addObject("model6", model6);
			   
			   
			   photo p7=pser.getphoto("GalleryImage5");
			     model7.addAttribute("image7", 
			     Base64.getEncoder().encodeToString(p7.getImage().getData()));
			    
			   ob.addObject("model7", model7);
			   
			   
			   photo p8=pser.getphoto("GalleryImage6");
			     model8.addAttribute("image8", 
			     Base64.getEncoder().encodeToString(p8.getImage().getData()));
			    
			   ob.addObject("model8", model8);
		      
		      
		     
		     
		     
		   
		      return ob;
		   }
	 
	 
	 
	 
	 @RequestMapping("/about")
	 
	 
		
		public ModelAndView about(Model model1) {
			
			
			
			
			ModelAndView ob= new ModelAndView("about");
			
			photo p1=pser.getphoto("AboutPage");
		    /* model1.addAttribute("image1", 
		     Base64.getEncoder().encodeToString(p1.getImage().getData()));*/
		  model1.addAttribute("dis",p1.getDescription());
			 
		      ob.addObject("model1", model1);
		     
			
			
			return ob;
					
			
		}
	 
	                             /*ADMIN PAGES LINKS*/
	 
	 
	 //image uploading CODE

	 
	 @RequestMapping( value= "/addphoto" )
	 
	 public ModelAndView addPhotoPage(){
		 
		 ModelAndView ob= new ModelAndView("addphoto");
		    
		 
		   return ob;
		 
	 }
	 
	 
	 
	 
	 
	 
	 
	 
 @RequestMapping( value= "/upload" ,method=RequestMethod.POST)
	 
	 public ModelAndView addPhoto(@RequestParam("title") String title, @RequestParam("id") String id,@RequestParam("price") int price,@RequestParam("description")String dis,
			  @RequestParam("image") MultipartFile image, Model model) 
			  throws IOException {
		 
		 
		 
		 photo p= new photo();
		 
		 
		 p.setPrice(price);
		 p.setDescription(dis);
		 p.setId(id);
		 p.setTitle(title);
		 p.setImage(
		          new Binary(BsonBinarySubType.BINARY, image.getBytes()));
		 
		 pser.addPhoto(p);
		 ModelAndView ob= new ModelAndView("home");
			    return ob;
			   
			}
 
 
 /*CODE FOR IMAGE AND TITLE PRICE ETC UPDATION BY ADMIN*/
 
 @RequestMapping(value="/updatefoodmenu")
	
	
	public ModelAndView updatefoodmenu(@RequestParam("title") String title, @RequestParam("id") String id,@RequestParam("price") int price,@RequestParam("description")String dis,
			  @RequestParam("image") MultipartFile image, Model model)throws IOException {
		

	
	 ModelAndView ob= new ModelAndView("admin");
 
		
		
        
		 
            photo p = pser.getphoto(id);
		 
		 p.setPrice(price);
		 p.setDescription(dis);
		 p.setId(id);
		 p.setTitle(title);
		 p.setImage(
		          new Binary(BsonBinarySubType.BINARY, image.getBytes()));
		 
	//	 pser.addPhoto(p);
		
			   
		pser.updatephoto(p);	   
		
	    
	
		
		return ob;
				
		
	}
	 
 
 
 
 /*WHEN HOME IS CLICKED IN ADMIN DASHBOARD*/
 
 @RequestMapping(value="/admin")
	
	
	public ModelAndView b1() {
		

	
	//List<emp>list=t.show();
 logger.debug("Getting all employees.");
 
 //Collection<user> c=serv.getAlluser();
 
 Collection<photo> c=pser.getAllphoto();

// System.out.print(c);
 
		ModelAndView ob= new ModelAndView("admin");
		
		
		
		
		//ob.addObject("list",list);
		
		ob.addObject("c", c);
		
	    
	
		
		return ob;
				
		
	}
 
 @RequestMapping( value= "/totaluser" )
 
 public ModelAndView getTotaluser() {
	 
	 
	 
	 ModelAndView ob= new ModelAndView("totaluser");
	 
	 Collection<user> c=serv.getAlluser();
	 
	
	 
		
			
			
			
			
			//ob.addObject("list",list);
			
			ob.addObject("c", c);
			

	 return ob;
	 
 }
 
 
 
 
	 
	 /*CODE FOR RETERIVING PHOTO FROM DATABSE*/
	 
 /*  SHOW PHOTO JSP FOR FOOD MENU*/
 
	 @RequestMapping("/foodmenu" )
	 public ModelAndView getPhoto( Model model1,Model model2,Model model3,Model model4,Model model5,Model model6,
			 Model model7, Model model8,Model model9) {
	     
		
		photo p1=pser.getphoto("Drink1");
		ModelAndView ob= new ModelAndView("foodmenu");
	     model1.addAttribute("title", p1.getTitle());
	     model1.addAttribute("image1", 
	     Base64.getEncoder().encodeToString(p1.getImage().getData()));
	     model1.addAttribute("id", p1.getId());
	     model1.addAttribute("title1", p1.getTitle());
	     model1.addAttribute("price1", p1.getPrice());
	     model1.addAttribute("dis1",p1.getDescription());
	
	     ob.addObject("model1", model1);
	     
	     
	     photo p2=pser.getphoto("Drink2");
			
		     model2.addAttribute("title", p2.getTitle());
		     model2.addAttribute("image2", 
		     Base64.getEncoder().encodeToString(p2.getImage().getData()));
		     model2.addAttribute("id", p2.getId());
		     model2.addAttribute("title2", p2.getTitle());
		     model2.addAttribute("price2", p2.getPrice());
		     model2.addAttribute("dis2",p2.getDescription());
			 
		     ob.addObject("model2", model2);
		    
		     
		     
		     
		     
		     
		    photo p3=pser.getphoto("Drink3");
				
		     model3.addAttribute("title", p3.getTitle());
		     model3.addAttribute("image3", 
		     Base64.getEncoder().encodeToString(p3.getImage().getData()));
		     model3.addAttribute("id", p3.getId());
		     model3.addAttribute("title3", p3.getTitle());
		     model3.addAttribute("price3", p3.getPrice());
		     model3.addAttribute("dis3",p3.getDescription());
			 
		     ob.addObject("model3", model3);
		    
			    photo p4=pser.getphoto("Snack1");
					
			     model4.addAttribute("title", p4.getTitle());
			     model4.addAttribute("image4", 
			     Base64.getEncoder().encodeToString(p4.getImage().getData()));
			     model4.addAttribute("id", p4.getId());
			     model4.addAttribute("title4", p4.getTitle());
			     model4.addAttribute("price4", p4.getPrice());
			     model4.addAttribute("dis4",p4.getDescription());
				 
			     ob.addObject("model4", model4);
		     
			     photo p5=pser.getphoto("Snack2");
					
			     model5.addAttribute("title", p5.getTitle());
			     model5.addAttribute("image5", 
			     Base64.getEncoder().encodeToString(p5.getImage().getData()));
			     model5.addAttribute("id", p5.getId());
			     model5.addAttribute("title5", p5.getTitle());
			     model5.addAttribute("price5", p5.getPrice());
			     model5.addAttribute("dis5",p5.getDescription());
				 
			     ob.addObject("model5", model5);
			     
			     photo p6=pser.getphoto("Snack3");
					
			     model6.addAttribute("title", p6.getTitle());
			     model6.addAttribute("image6", 
			     Base64.getEncoder().encodeToString(p6.getImage().getData()));
			     model6.addAttribute("id", p6.getId());
			     model6.addAttribute("title6", p6.getTitle());
			     model6.addAttribute("price6", p6.getPrice());
			     model6.addAttribute("dis6",p6.getDescription());
				 
			     ob.addObject("model6", model6);
	     
	 
	     
			     photo p7=pser.getphoto("Desert1");
					
			     model7.addAttribute("title", p7.getTitle());
			     model7.addAttribute("image7", 
			     Base64.getEncoder().encodeToString(p7.getImage().getData()));
			     model7.addAttribute("id", p7.getId());
			     model7.addAttribute("title7", p7.getTitle());
			     model7.addAttribute("price7", p7.getPrice());
			     model7.addAttribute("dis7",p7.getDescription());
				 
			     ob.addObject("model7", model7);
	     
			     
			     photo p8=pser.getphoto("Desert2");
					
			     model8.addAttribute("title", p8.getTitle());
			     model8.addAttribute("image8", 
			     Base64.getEncoder().encodeToString(p8.getImage().getData()));
			     model8.addAttribute("id", p8.getId());
			     model8.addAttribute("title8", p8.getTitle());
			     model8.addAttribute("price8", p8.getPrice());
			     model8.addAttribute("dis8",p8.getDescription());
				 
			     ob.addObject("model8", model8);
	     
			     
			     photo p9=pser.getphoto("Desert3");
					
			     model9.addAttribute("title", p9.getTitle());
			     model9.addAttribute("image9", 
			     Base64.getEncoder().encodeToString(p9.getImage().getData()));
			     model9.addAttribute("id9", p9.getId());
			     model9.addAttribute("title9", p9.getTitle());
			     model9.addAttribute("price9", p9.getPrice());
			     model9.addAttribute("dis9",p9.getDescription());
				 
			     ob.addObject("model9", model9);
	     
			     
			     
			     
			     
			     
			     
			     
			     
			     
	     
	     
	     return ob;
	    
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
	 
	
	 
	 
	 
	 /* PAGE WHEN SIGN IN LINK IS PRESSSED ON NAV BAR  */
	 
	 
	 @RequestMapping("/signin")
	 
		
		
		public ModelAndView signup() {
			
			
			
			ModelAndView ob= new ModelAndView("login");
			sign=true;
			
			return ob;
					
			
		}
	 
	 @RequestMapping("/logoutuser")
	 
		
		
		public ModelAndView logoutuser(Model model1,Model model2,Model model3,
				Model model4,Model model5,Model model6,Model model7,Model model8) {
			
			c.clear();
			total=0;
			size=0;
			sign=false;
			placesign=false;
			username=null;
			transaction=null;
			useremail=null;
			
			  ModelAndView ob= new ModelAndView("home");
				photo p1=pser.getphoto("HomePage1");
			     model1.addAttribute("image1", 
			     Base64.getEncoder().encodeToString(p1.getImage().getData()));
			  
				 
			      ob.addObject("model1", model1);
			     
			      
			      
			      
			      
			      
			      photo p2=pser.getphoto("HomePage2");
				     model2.addAttribute("image2", 
				     Base64.getEncoder().encodeToString(p2.getImage().getData()));
				     model2.addAttribute("dis2", p2.getDescription());
				   ob.addObject("model2", model2);
				     
			      
				   photo p3=pser.getphoto("GalleryImage1");
				     model3.addAttribute("image3", 
				     Base64.getEncoder().encodeToString(p3.getImage().getData()));
				    
				   ob.addObject("model3", model3);
				  
			      
				   
				   photo p4=pser.getphoto("GalleryImage2");
				     model4.addAttribute("image4", 
				     Base64.getEncoder().encodeToString(p4.getImage().getData()));
				    
				   ob.addObject("model4", model4);
				   
				   
				   photo p5=pser.getphoto("GalleryImage3");
				     model5.addAttribute("image5", 
				     Base64.getEncoder().encodeToString(p5.getImage().getData()));
				    
				   ob.addObject("model5", model5);
				   
				   
				   photo p6=pser.getphoto("GalleryImage4");
				     model6.addAttribute("image6", 
				     Base64.getEncoder().encodeToString(p6.getImage().getData()));
				    
				   ob.addObject("model6", model6);
				   
				   
				   photo p7=pser.getphoto("GalleryImage5");
				     model7.addAttribute("image7", 
				     Base64.getEncoder().encodeToString(p7.getImage().getData()));
				    
				   ob.addObject("model7", model7);
				   
				   
				   photo p8=pser.getphoto("GalleryImage6");
				     model8.addAttribute("image8", 
				     Base64.getEncoder().encodeToString(p8.getImage().getData()));
				    
				   ob.addObject("model8", model8);
			      
			      
			     
			     
			     
			   
			      return ob;
		
					
			
		}
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 /* PAGE WHEN createaccount  LINK IS PRESSSED ON LOGIN PAGE  */
	 
	 @RequestMapping("/createaccount")
		
		
		public ModelAndView createaccount() {
			
			
			
			
			ModelAndView ob= new ModelAndView("register");
			
			return ob;
					
			
		}
	 
	
	 
	 /* PAGE WHEN FORGOT  LINK IS PRESSSED ON LOGIN PAGE  */
	 
	 @RequestMapping("/forgot")
		
		
		public ModelAndView forgot() {
			
			

			 
			ModelAndView ob= new ModelAndView("forgot");
			
			return ob;
					
		 
		}
	 
	 
	 /* PAGE WHEN PASSWORD IS CHANGED LINK IS PRESSSED ON FORGOT  PAGE  */
	 @RequestMapping("/forlogin")
		
		
		public ModelAndView forlogin() {
			
			
			
			
			ModelAndView ob= new ModelAndView("login");
			
			return ob;
					
			
		}
	 
	 
	 /* PAGE WHEN forgot  BUTTON IS CLICKED ON login page */
	 @RequestMapping("/forgotform")
		
		
		public ModelAndView forgot2(@RequestParam("email")String e,@RequestParam("password")String pass,@RequestParam("confirmpass")String cpass) {
			
		 
		 user userExists = serv.findUserByEmail(e)  ;
		 
		 String getuseremail=userExists.getEmail();
		 
		 System.out.print(userExists);
		 
		 
		 
		 if(getuseremail.equals(e)&&pass.equals(cpass)) {
		 
			 
			 userExists.setPassword(pass);
			
			 serv.updateuser(userExists);
			
			ModelAndView ob= new ModelAndView("home"); /*the entered email exist forward to another page*/
			
			
			return ob;
		 }else {
			 
			 
			 return new ModelAndView("forgot");
		 }		
		  
		   }
	 
	 
	 
	 /*PAGE WHEN USER CLICK ON HOEM IN USER DASHBOARD*/
	 
	 @RequestMapping("/userhome")
	 
	 public ModelAndView userhome(Model model1){
		 
		 
		 
		 ModelAndView ob1= new ModelAndView("userdashboard");
			
		 
		 
		 
		 
         logger.debug("Getting all product details");
		    
		    Collection<photo> c=pser.getAllproduct();
		    
		    int size=c.size();
		    
		
		    
		    model1.addAttribute("total",total);
		    model1.addAttribute("totalitems",size);
		
		   
		    
		    
		    model1.addAttribute("name", username);
			ob1.addObject("model1", model1);
			
				
				ob1.addObject("c", c);
			
			
		 
		
		 
		
		

	
		 return ob1;
		 
		 
		 
		 
		 
		 
	 }
	 
	 
	 
	 
	 /*WHEN USER ON LOGIN BUTTON ON LOGIN JSP*/
	 
	 @RequestMapping("/loguser")
		
		
		public ModelAndView loguser(@RequestParam("email")String email,@RequestParam("pass")String pass,
				
				 Model model1,Model model2,Model model3,
					Model model4,Model model5,Model model6,Model model7,Model model8
				) {
		 
		 
		 
		 
		 user userExists = serv.findUserByEmail(email)  ;
		 String getuserpass=userExists.getPassword();
		 String getuseremail=userExists.getEmail();
		 String name=userExists.getName();
		 
		 
		 if(getuseremail.equals(email)&&getuserpass.equals(pass)) {
			 
			
			 if(email.equals("admin@gmail.com")&& pass.equals("admin@123")) {
				 
				 ModelAndView ob= new ModelAndView("admin");
				 
				
				 
				 logger.debug("Getting all employees.");
				    
				   // Collection<user> c=serv.getAlluser();
				    
				 
				 Collection<photo> cd=pser.getAllphoto();
			
						
						ob.addObject("c", cd);
						
					    
					
				 
				
			
				 return ob;
			 }else {
				 
				 username=name;
				 useremail= getuseremail;
				 if(placesign==true) {
					 
					 c=pser.getAllproduct();
					    
					    int size1=c.size();
					   
					    
					    if(c.size()>0) {
					   
					    

					    ModelAndView ob1= new ModelAndView("userdashboard");
					    model1.addAttribute("total",total);
					    model1.addAttribute("totalitems",size1);
					
					   
					 /*   orders ob= new orders();
					    
					    ob.setEmail(useremail);
					    ob.setName(username);
					    ob.setTotalamount(total);
					    ob.setNoofitems(size);
					    
					    
					    
					    orderserv.createorder(ob);*/
					    size=size1;
					    
					    model1.addAttribute("name",username);
						ob1.addObject("model1", model1);
						
							
							ob1.addObject("c", c);
						
						
					 
							 return ob1;
					 
					    }else {
					    	ModelAndView ob1= new ModelAndView("userorders"); 	
					    	
					    	  model1.addAttribute("name", username);
								ob1.addObject("model1", model1);
					    	
					    
					    	
					    	
					    	 return ob1;
					    	
					    	
					    }
					 
					 
					 
					 
					 
					 
				 }else {
				 
				 
				 sign=true;
				 
			 
			/*	logger.debug("Getting all product details");
			    
			 c=pser.getAllproduct();
			    
			    int size=c.size();
			    
			    
			    if(c.size()>0) {
			    
			    

			    ModelAndView ob1= new ModelAndView("userdashboard");
			    model1.addAttribute("total",total);
			    model1.addAttribute("totalitems",size);
			
			   
			    
			    
			    model1.addAttribute("name", name);
				ob1.addObject("model1", model1);
				
					
					ob1.addObject("c", c);
				
				
			 
					 return ob1;
			 
			    }else {
			    	ModelAndView ob1= new ModelAndView("userorders"); 	
			    	username=name;
			    	  model1.addAttribute("name", name);
						ob1.addObject("model1", model1);
			    	
			    
			    	
			    	
			    	 return ob1;
			    	
			    	
			    }*/
			
			
				 
				 
				 ModelAndView ob= new ModelAndView("home");
				 
				 photo p1=pser.getphoto("HomePage1");
			     model1.addAttribute("image1", 
			     Base64.getEncoder().encodeToString(p1.getImage().getData()));
			  
				 
			      ob.addObject("model1", model1);
			     
			      
			      
			      
			      
			      
			      photo p2=pser.getphoto("HomePage2");
				     model2.addAttribute("image2", 
				     Base64.getEncoder().encodeToString(p2.getImage().getData()));
				     model2.addAttribute("dis2", p2.getDescription());
				   ob.addObject("model2", model2);
				     
			      
				   photo p3=pser.getphoto("GalleryImage1");
				     model3.addAttribute("image3", 
				     Base64.getEncoder().encodeToString(p3.getImage().getData()));
				    
				   ob.addObject("model3", model3);
				  
			      
				   
				   photo p4=pser.getphoto("GalleryImage2");
				     model4.addAttribute("image4", 
				     Base64.getEncoder().encodeToString(p4.getImage().getData()));
				    
				   ob.addObject("model4", model4);
				   
				   
				   photo p5=pser.getphoto("GalleryImage3");
				     model5.addAttribute("image5", 
				     Base64.getEncoder().encodeToString(p5.getImage().getData()));
				    
				   ob.addObject("model5", model5);
				   
				   
				   photo p6=pser.getphoto("GalleryImage4");
				     model6.addAttribute("image6", 
				     Base64.getEncoder().encodeToString(p6.getImage().getData()));
				    
				   ob.addObject("model6", model6);
				   
				   
				   photo p7=pser.getphoto("GalleryImage5");
				     model7.addAttribute("image7", 
				     Base64.getEncoder().encodeToString(p7.getImage().getData()));
				    
				   ob.addObject("model7", model7);
				   
				   
				   photo p8=pser.getphoto("GalleryImage6");
				     model8.addAttribute("image8", 
				     Base64.getEncoder().encodeToString(p8.getImage().getData()));
				    
				   ob.addObject("model8", model8);
			      
			      
			     
			     
		return ob;
			
			 }
			 }
			 
		 }else {
			
		 
			 return new ModelAndView("login");
		
		 }
		}
	 
	 
	/*PAGE WHEN REGISTER BUTTON IN CLICKED*/
	 
	 @RequestMapping(value= "/register" ,method=RequestMethod.POST)
	   public ModelAndView create(@RequestParam("email")String e,@RequestParam("name")String n,@RequestParam("phoneno")String p,@RequestParam("password")String ps) {
	       logger.debug("Saving employees.");
	     
	      // int ph=Integer.parseInt(p);
	     
	      
	       
	       //Collection<user> c=serv.getAlluser();
	      // System.out.print(c);
	     
	       user userExists = serv.findUserByEmail(e)  ;
	       
	   System.out.print(userExists);
	   if (userExists != null) {
		   
		
	       ModelAndView ob= new ModelAndView("reigster");
	       ob.addObject("a", "This email is already registered please register with another email");
		   return new ModelAndView("reigster");
	    }else
	       {
	       user em= new user();
	       
	       em.setEmail(e);
	       em.setName(n);
	       em.setPassword(ps);
	      em.setPhoneno(p);
	      serv.createuser(em);
	     	       
	      
	      ModelAndView ob1= new ModelAndView("login");
	      //ob1.addObject("em", em);
	  
	       
	   
	      return ob1;
	      }
	       
	   }
	 
	 
	 
	 
	 /*When show user button is clicked on admin panel  */
	
	 
	
	 public static String getTransactionID() {
		 
		 
		 
		 
		 int count=8;
			
			
			StringBuilder builder = new StringBuilder();
			
			int character = (int)(Math.random()*ALPHA_NUMERIC_STRING_BEG.length());
			builder.append(ALPHA_NUMERIC_STRING_BEG.charAt(character));
			
			
			while (count-- != 0) {
			 character = (int)(Math.random()*ALPHA_NUMERIC_STRING_NUM.length());
			builder.append(ALPHA_NUMERIC_STRING_NUM.charAt(character));
			
			
			
		}
			character = (int)(Math.random()*ALPHA_NUMERIC_STRING_END.length());
			builder.append(ALPHA_NUMERIC_STRING_END.charAt(character));
			
			
			
			return builder.toString();
		 
		 
	 }
	 
	 
	 public static void sendmail() {
		 
		 final String username="manjyotjpr@gmail.com";
			final String pass="ipss@4110";
			String to="manjyotjpr@gmail.com";
			String rmail="manjyotjpr@gmail.com";
			String subject="Transaction Received";
			String msg="Transaction Received";
			
			Properties pro= new Properties();
			
			pro.put("mail.smtp.host", "smtp.gmail.com");
			pro.put("mail.smtp.auth", "true");
			pro.put("mail.debug", "true");
			
			pro.put("mail.smtp.port", "465");
			pro.put("mail.smtp.socketFactory.port", "465");
			pro.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			pro.put("mail.smtp.socketFactory.fallback", "false");
			
			
			Session s=Session.getInstance(pro,new Authenticator() {
				

			    @Override
			    protected PasswordAuthentication getPasswordAuthentication() {
			    	// TODO Auto-generated method stub
			    	return new PasswordAuthentication("manjyotjpr@gmail.com","ipss@4110");
			    }
			});
		 
			try {
				
				/*Message ms=new MimeMessage(session);
				ms.setFrom(new InternetAddress(username));
	// Set From: header field of the header andset the actual message

		ms.setRecipients(Message.RecipientType.TO,InternetAddress.parse(rmail));
				ms.setSubject(subject);
				ms.setText(msg);
				Transport.send(ms);
				System.out.println("Message Successfully sent");*/
				
				
				// TO SEND AN ATTACHMENT WITH FILE
				   MimeMessage message = new MimeMessage(s);  
				    message.setFrom(new InternetAddress(username));  
				    message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
				    message.setSubject("Message Aleart");  
				      
				    //3) create MimeBodyPart object and set your message text     
				    BodyPart messageBodyPart1 = new MimeBodyPart();  
				    messageBodyPart1.setText(msg);  
				      
				    //4) create new MimeBodyPart object and set DataHandler object to this object      
				    MimeBodyPart messageBodyPart2 = new MimeBodyPart();  
				  
				   /* String filename = "attch.java";//change accordingly  
				    DataSource source = new FileDataSource(filename);  
				    messageBodyPart2.setDataHandler(new DataHandler(source));  
				    messageBodyPart2.setFileName(filename);  
				     */
				     
				    //5) create Multipart object and add MimeBodyPart objects to this object      
				    Multipart multipart = new MimeMultipart();  
				    multipart.addBodyPart(messageBodyPart1);  
				   // multipart.addBodyPart(messageBodyPart2);  
				 
				    //6) set the multiplart object to the message object  
				    message.setContent(multipart );  
				     
				    //7) send message  
				    Transport.send(message);  
				   
				   System.out.println("message sent....");
			}catch(Exception e) {
				System.out.println("Message NOT sent");
				
			}
		}
		 
	 }
	 
	 
	 
	 
	 
	 

	
	 
	
	
	
	
	
	
	
	
	
	

