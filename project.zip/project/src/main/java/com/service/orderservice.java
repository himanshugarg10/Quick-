package com.service;

import java.util.Collection;

import com.model.orders;


public interface orderservice {
	
	
	
	public void createorder(orders order);

	public Collection<orders> getAllorders();
	
	
	
	 public orders findUserByEmail(String email);

}
