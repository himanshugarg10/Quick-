package com.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.dao.photorepository;
import com.model.photo;
import com.model.user;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import org.bson.BsonBinarySubType;
import org.bson.types.Binary;
import org.springframework.beans.factory.annotation.Autowired;


//SERVICE CLASS FOR FOOD MENU 

@Service
public class photoservice implements photoser {


	
	Collection<photo> addProduct= new ArrayList<photo>();
	
	
	 @Autowired
	    private photorepository photoRepo;
	 
	 
	 
	  
	 
	    public void addPhoto(photo p) { 
	       
	      //  photo photo=new photo();
	       // photo.setTitle("hhello");
	        //photo.setImage(
	          //new Binary(BsonBinarySubType.BINARY, file.getBytes())); 
	         photoRepo.insert(p);
	         photoRepo.save(p);
	         
	        
	    }
	 
	   

		public photo getphoto(String id) {
			// TODO Auto-generated method stub
			return photoRepo.findById(id).get(); 
		}



		public Collection<photo> getAllphoto() {
			// TODO Auto-generated method stub
			return photoRepo.findAll();
		}



		public void updatephoto(photo p) {
			// TODO Auto-generated method stub
			  photoRepo.save(p);
			
		}



		public void addproduct(photo p) {
			// TODO Auto-generated method stub
			
			addProduct.add(p);
			
		}



		public Collection<photo> getAllproduct() {
			// TODO Auto-generated method stub
			return addProduct;
		}



		
	
	
	
	
	
	
	
}
