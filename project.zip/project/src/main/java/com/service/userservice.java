package com.service;

import java.util.Collection;

import com.model.user;

public interface userservice {
	
	
	
	public void createuser(user user);

	public Collection<user> getAlluser();
	
	public void updateuser(user u);
	
	 public user findUserByEmail(String email);

}
