package com.service;

import java.io.IOException;


import java.util.Collection;

import org.springframework.web.multipart.MultipartFile;

import com.model.photo;
import com.model.user;


//PHOTO INTERFACE FOR FOOF MENU

public interface photoser {
	
	
	public void addPhoto(photo p)  throws IOException;
	
	
	public photo getphoto(String id);
	
	
	public Collection<photo> getAllphoto();
	
	public void updatephoto(photo p);
	
	
	public void addproduct(photo p) ;
	
	public Collection<photo> getAllproduct();

}
