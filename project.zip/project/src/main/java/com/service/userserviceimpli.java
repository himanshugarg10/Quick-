package com.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.userdao;

import com.model.user;


@Service
public class userserviceimpli implements userservice {
	
	
	 @Autowired
	 userdao dao;

	public void createuser(user user) {
		// TODO Auto-generated method stub
		

                    dao.save(user);
                    
		
	}
	
	
	 public Collection<user> getAlluser(){
		   
		 
		   return dao.findAll();
	   }
	   
	   public void updateuser(user u) {
	       dao.save(u);
	   }

	   
	   
	   public user findUserByEmail(String email) {
		    return  dao.findByEmail(email);
		}

}
