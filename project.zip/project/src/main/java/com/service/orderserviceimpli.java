package com.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.orderdao;

import com.model.orders;

@Service
public class orderserviceimpli implements orderservice {

	 @Autowired
	orderdao dao;
	
	
	public void createorder(orders order) {
		// TODO Auto-generated method stub
		
		
		dao.save(order);
		
	}

	public Collection<orders> getAllorders() {
		// TODO Auto-generated method stub
		return null;
	}

	public orders findUserByEmail(String email) {
		// TODO Auto-generated method stub
		return null;
	}

}
